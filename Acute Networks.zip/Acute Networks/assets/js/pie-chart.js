

    const donutChartAchieved = 45100;
    const donutChartTarget = 71500;
    const todayRevenue = 16200;
    const yesterdayRevenue = 14700;
    const donutChartPercentage = Math.round((donutChartAchieved / donutChartTarget) * 100);

    const donutChartCircle = document.querySelector('.donut-progress');
    const donutChartRadius = 80;
    const donutChartCircumference = 2 * Math.PI * donutChartRadius;

    donutChartCircle.setAttribute('stroke-dasharray', donutChartCircumference);
    donutChartCircle.setAttribute('stroke-dashoffset', donutChartCircumference);

    let donutChartStrokeColor = '#22c55e';
    let donutChartBadgeIcon = '';
    let donutChartBadgeLabel = '';

    if (donutChartPercentage >= 125) {
      donutChartStrokeColor = '#facc15';
      donutChartBadgeIcon = '🥇';
      donutChartBadgeLabel = '+5% Incentive';
    } else if (donutChartPercentage >= 110) {
      donutChartStrokeColor = '#60a5fa';
      donutChartBadgeIcon = '🥈';
      donutChartBadgeLabel = '+4% Incentive';
    } else if (donutChartPercentage >= 100) {
      donutChartStrokeColor = '#fb923c';
      donutChartBadgeIcon = '🥉';
      donutChartBadgeLabel = '+3% Incentive';
    } else if (donutChartPercentage >= 75) {
      donutChartStrokeColor = '#10B981';
      donutChartBadgeIcon = '🎯';
      donutChartBadgeLabel = '75% Reached';
    } else {
      donutChartStrokeColor = '#ef4444';
      donutChartBadgeIcon = '🔥';
      donutChartBadgeLabel = 'Keep Going';
    }

    donutChartCircle.setAttribute('stroke', donutChartStrokeColor);
    document.getElementById('donut-achievedText').textContent = donutChartAchieved.toLocaleString();
    document.getElementById('donut-targetText').textContent = donutChartTarget.toLocaleString();
    document.getElementById('todayRevenue').textContent = todayRevenue.toLocaleString();
    document.getElementById('yesterdayRevenue').textContent = yesterdayRevenue.toLocaleString();

    setTimeout(() => {
      const donutChartDisplayPercent = Math.min(donutChartPercentage, 100);
      const donutChartOffset = donutChartCircumference - (donutChartDisplayPercent / 100) * donutChartCircumference;
      donutChartCircle.setAttribute('stroke-dashoffset', donutChartOffset);

      let donutChartCount = 0;
      const donutChartStep = () => {
        if (donutChartCount <= donutChartPercentage) {
          document.getElementById('donut-percentText').textContent = donutChartCount;
          donutChartCount++;
          requestAnimationFrame(donutChartStep);
        }
      };
      donutChartStep();

      if (donutChartBadgeIcon) {
        document.getElementById('donut-incentiveBadge').innerHTML = `${donutChartBadgeIcon}<small>${donutChartBadgeLabel}</small>`;
      }

      if (donutChartPercentage > 100) {
        donutChartCircle.classList.add('over');
      }

      if (donutChartPercentage >= 100) {
        const confettiCanvas = document.getElementById('donut-confettiCanvas');
        const myConfetti = confetti.create(confettiCanvas, { resize: true, useWorker: true });
        myConfetti({ particleCount: 200, spread: 90, origin: { y: 0.6 } });
      }
    }, 300);

    document.getElementById('donut-datePicker').value = new Date().toISOString().split('T')[0];
