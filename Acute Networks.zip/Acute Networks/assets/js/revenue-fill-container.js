
const earned = 120000;
const totalIncentive = 80000;
const percentage = Math.round((earned / totalIncentive) * 100);
  
  const percentLabel = document.getElementById('percentLabel');
  const earnText = document.getElementById('earnText');
  const titleEl = document.getElementById('rewardTitle');
  const rewardSummary = document.querySelector('.reward-box small');
  const incentiveInfo = document.getElementById('incentiveInfo');
  const wavePath = document.getElementById("wavePath");
  const tooltip = document.getElementById("tooltip");

  // Animate count
  function animateCountUp(el, target) {
    let start = 0;
    const duration = 1000;
    const step = Math.ceil(target / (duration / 30));

    const counter = setInterval(() => {
      start += step;
      if (start >= target) {
        start = target;
        clearInterval(counter);
      }
      el.textContent = `₹${start.toLocaleString()} / ₹${totalIncentive.toLocaleString()}`;
    }, 30);
  }

  percentLabel.innerHTML = `${percentage}% <small>REVENUE</small>`;
  animateCountUp(earnText, earned);

  if (percentage <= 51) {
    titleEl.textContent = "Keep Going 🚀";
  } else if (percentage <= 95) {
    titleEl.textContent = "Almost There 💪";
  } else {
    titleEl.textContent = "Goal Hit 🏆";
  }

 let incentiveText = "No incentive achieved yet.";
if (percentage >= 125) {
  incentiveText = "🎉 Platinum 💎 Achieved – Enjoy 5% Bonus Incentive!";
} else if (percentage >= 110) {
  incentiveText = "🏅 Gold 🥇 Achieved – Earned 4% Bonus Incentive!";
} else if (percentage >= 100) {
  incentiveText = "✅ Silver 🥈 Achieved – You've earned a 3% Bonus Incentive !";
} else if (percentage >= 75) {
  incentiveText = "🎯 Great! You've reached 75% – Keep pushing toward Silver!";
}
rewardSummary.textContent = incentiveText;

let nextIncentives = "";

if (percentage < 100) {
  const req = Math.round((100 / 100 * totalIncentive) - earned);
  nextIncentives = `🚀 ₹${req.toLocaleString()} more to unlock Silver 🥈 and a 3% Bonus!`;
} else if (percentage < 110) {
  const req = Math.round((110 / 100 * totalIncentive) - earned);
  nextIncentives = `✨ ₹${req.toLocaleString()} more to reach Gold 🥇 and 4% Bonus!`;
} else if (percentage < 125) {
  const req = Math.round((125 / 100 * totalIncentive) - earned);
  nextIncentives = `💎 ₹${req.toLocaleString()} more to reach Platinum 💎 and 5% Bonus!`;
} else {
  nextIncentives = `🏆 You've unlocked all incentive tiers – Excellent job!`;
}

incentiveInfo.textContent = nextIncentives;

incentiveInfo.textContent = nextIncentives;

  // Color Logic
  let waveColor = "rgba(76, 175, 80, 0.6)";
  if (percentage <= 50) {
    waveColor = "rgba(239, 68, 68, 0.6)";
  } else if (percentage < 75) {
    waveColor = "rgba(251, 146, 60, 0.6)";
  } else if (percentage < 100) {
    waveColor = "rgba(250, 204, 21, 0.6)";
  } else if (percentage < 110) {
    waveColor = "rgba(34, 197, 94, 0.6)";
  } else if (percentage < 125) {
    waveColor = "rgba(5, 150, 105, 0.6)";
  } else {
    waveColor = "rgba(14, 165, 233, 0.6)";
  }

  wavePath.setAttribute("fill", waveColor);

  // Wave Generator
  function generateWave(time, amplitude, bones, baseY) {
    let path = `M0,20 `;
    for (let i = 0; i <= bones; i++) {
      let x = (i / bones) * 100;
      let sinSeed = (time + i * 100);
      let y = amplitude * Math.sin(sinSeed / 100);
      path += `L${x},${baseY - y} `;
    }
    path += `L100,20 Z`;
    return path;
  }

  function animateWave() {
    let time = 0;
    const amplitude = 2.5;
    const bones = 5;
    const baseY = Math.max(0, 20 - (percentage / 100 * 20));

    function frame() {
      time += 1;
      wavePath.setAttribute("d", generateWave(time, amplitude, bones, baseY));
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  animateWave();

  // Tooltip
  const waveWrapper = document.getElementById("waveWrapper");
  waveWrapper.addEventListener("mouseenter", () => {
    tooltip.textContent = `₹${earned.toLocaleString()} of ₹${totalIncentive.toLocaleString()}`;
    tooltip.style.display = "block";
  });
  waveWrapper.addEventListener("mouseleave", () => {
    tooltip.style.display = "none";
  });
  waveWrapper.addEventListener("mousemove", (e) => {
    tooltip.style.left = e.pageX + "px";
  });

  // Confetti
  if (percentage >= 100) {
    for (let i = 0; i < 100; i++) {
      const conf = document.createElement('div');
      conf.style.position = 'fixed';
      conf.style.top = Math.random() * 100 + '%';
      conf.style.left = Math.random() * 100 + '%';
      conf.style.width = '6px';
      conf.style.height = '6px';
      conf.style.background = `hsl(${Math.random() * 360}, 100%, 60%)`;
      conf.style.borderRadius = '50%';
      conf.style.zIndex = 999;
      conf.style.opacity = 1;
      conf.style.animation = 'fall 3s ease-out forwards';
      document.body.appendChild(conf);
      setTimeout(() => conf.remove(), 3000);
    }
  }
  const style = document.createElement("style");
  style.textContent = `
    @keyframes fall {
      0% { transform: translateY(0) rotate(0); }
      100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
    }
  `;
  document.head.appendChild(style);
